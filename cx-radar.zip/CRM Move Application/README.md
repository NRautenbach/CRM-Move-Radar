# CX Demand Generation Dashboard — Phase 1

## Requirements
- Python 3.9+ (already on your Mac)
- Required packages (installed once):

```bash
pip3 install flask pyxlsb --user
```

## Run the app

```bash
cd "/Users/i356184/CRM Move Application"
python3 app.py
```

Then open: **http://localhost:3000**

## Usage
1. Click **Choose File** and select `CX Installed Base.xlsb`
2. The app reads the **Customers** worksheet automatically
3. Only records where **Column O (CRM OP)** is not blank and not "Moved" are included
4. Use the **filter panel** (left sidebar) to narrow by segment, owner, etc.
5. **Click any country** on the map to see its detailed records in the table below
6. Click column headers in the table to **sort**

## Project Structure
```
CRM Move Application/
├── app.py          ← Flask server + data logic
├── static/
│   └── index.html  ← Single-page dashboard (map, filters, table)
└── uploads/        ← Uploaded file stored here temporarily
```
