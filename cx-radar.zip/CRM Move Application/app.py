import os
import sys
import io
import math
import csv

# Local dev: add user site-packages
sys.path.insert(0, os.path.expanduser('~/Library/Python/3.9/lib/python/site-packages'))

from flask import Flask, request, jsonify, send_from_directory, Response
from pyxlsb import open_workbook

app = Flask(__name__, static_folder='static')

# Default file: local Mac path for dev, uploads folder for cloud
_local_default = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'CX Installed Base 07062026.xlsb')
DEFAULT_FILE    = _local_default if os.path.exists(_local_default) else None
UPLOAD_FOLDER   = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Column indices (0-based) in the Customers sheet — updated 07/06/2026
COL_PLANNING_ENTITY_NAME = 0   # A
COL_PLANNING_ENTITY_CRM  = 1   # B
COL_PLANNING_ENTITY_ERP  = 2   # C
COL_REGION               = 3   # D
COL_MARKET_UNIT          = 4   # E
COL_COUNTRY              = 5   # F
COL_GLOBAL_ULTIMATE      = 6   # G
COL_MASTER_CODE          = 7   # H
COL_INT_SALES_SEG        = 8   # I
COL_SALES_GROUP          = 9   # J
COL_ACCOUNT_OWNER        = 10  # K
COL_SSE_SPECIALIST       = 11  # L
COL_MTC_BAND             = 12  # M - NEW
COL_C4C_SHARE            = 13  # N
COL_COMMERCE_SHARE       = 14  # O
COL_CRM_OP               = 15  # P
COL_HDB                  = 19  # T
COL_ASE                  = 20  # U
COL_MAX_DB               = 21  # V
COL_ORACLE               = 22  # W
COL_MS_SQL               = 23  # X
COL_IBM_DB2              = 24  # Y
COL_OTHERS               = 25  # Z
COL_AK                   = 36  # AK - ERP Private License
COL_AL                   = 37  # AL - ERP Private Opportunity
COL_AM                   = 38  # AM - ERP PTO Opportunity
COL_AN                   = 39  # AN - RISE License
COL_AO                   = 40  # AO - RISE Opportunity
COL_AP                   = 41  # AP - S/4 PTO Opportunity

# Filter columns
FILTER_COLS = {
    'col_i':   COL_INT_SALES_SEG,
    'col_k':   COL_ACCOUNT_OWNER,
    'col_l':   COL_SSE_SPECIALIST,
    'col_m':   COL_MTC_BAND,
    'col_s':   COL_HDB,
    'col_ao':  COL_AO,
    'col_ap':  COL_AP,
}

# Region/MU are handled separately (hierarchical)
COL_REGION_IDX      = COL_REGION
COL_MARKET_UNIT_IDX = COL_MARKET_UNIT

def safe_val(v):
    if v is None:
        return ''
    if isinstance(v, float):
        if math.isnan(v) or math.isinf(v):
            return ''
        if v == int(v):
            return int(v)
        return v
    return v

def read_xlsb_customers(filepath):
    rows = []
    with open_workbook(filepath) as wb:
        with wb.get_sheet('Customers') as sheet:
            for i, row in enumerate(sheet.rows()):
                if i == 0:
                    continue  # skip header
                vals = [cell.v for cell in row]
                # Pad to ensure we have enough columns
                while len(vals) <= COL_AP:
                    vals.append(None)
                rows.append(vals)
    return rows

def filter_rows(rows, filters=None):
    result = []
    region_filter = (filters or {}).get('region', '')
    mu_filter      = (filters or {}).get('market_unit', '')
    country_filter = (filters or {}).get('countries', [])  # list for multi-select
    for vals in rows:
        crm_op = vals[COL_CRM_OP]
        if crm_op is None or crm_op == '':
            continue
        if str(crm_op).strip() == 'Moved':
            continue
        # Region / Market Unit / Country hierarchical filters
        if region_filter:
            if str(safe_val(vals[COL_REGION_IDX])).strip() != region_filter:
                continue
        if mu_filter:
            if str(safe_val(vals[COL_MARKET_UNIT_IDX])).strip() != mu_filter:
                continue
        if country_filter:
            if str(safe_val(vals[COL_COUNTRY])).strip() not in country_filter:
                continue
        # Other sidebar filters
        if filters:
            skip = False
            for col_key, col_idx in FILTER_COLS.items():
                selected = filters.get(col_key, [])
                if selected:
                    cell_val = str(safe_val(vals[col_idx])) if vals[col_idx] is not None else ''
                    if cell_val not in selected:
                        skip = True
                        break
            if skip:
                continue
        result.append(vals)
    return result

def rows_to_records(rows):
    records = []
    for vals in rows:
        records.append({
            'planning_entity_name': safe_val(vals[COL_PLANNING_ENTITY_NAME]),
            'planning_entity_crm':  safe_val(vals[COL_PLANNING_ENTITY_CRM]),
            'planning_entity_erp':  safe_val(vals[COL_PLANNING_ENTITY_ERP]),
            'region':               safe_val(vals[COL_REGION]),
            'market_unit':          safe_val(vals[COL_MARKET_UNIT]),
            'country':              safe_val(vals[COL_COUNTRY]),
            'global_ultimate':      safe_val(vals[COL_GLOBAL_ULTIMATE]),
            'master_code':          safe_val(vals[COL_MASTER_CODE]),
            'int_sales_seg':        safe_val(vals[COL_INT_SALES_SEG]),
            'account_owner':        safe_val(vals[COL_ACCOUNT_OWNER]),
            'sse_specialist':       safe_val(vals[COL_SSE_SPECIALIST]),
            'mtc_band':             safe_val(vals[COL_MTC_BAND]),
            'crm_op':               safe_val(vals[COL_CRM_OP]),
            'hdb':                  safe_val(vals[COL_HDB]),
            'ase':                  safe_val(vals[COL_ASE]),
            'max_db':               safe_val(vals[COL_MAX_DB]),
            'oracle':               safe_val(vals[COL_ORACLE]),
            'ms_sql':               safe_val(vals[COL_MS_SQL]),
            'ibm_db2':              safe_val(vals[COL_IBM_DB2]),
            'others':               safe_val(vals[COL_OTHERS]),
            'erp_private_license':  safe_val(vals[COL_AK]),
            'erp_private_opp':      safe_val(vals[COL_AL]),
            'erp_pto_opp':          safe_val(vals[COL_AM]),
            'rise_license':         safe_val(vals[COL_AN]),
            'rise_opportunity':     safe_val(vals[COL_AO]),
            's4_pto_opportunity':   safe_val(vals[COL_AP]),
        })
    return records

# Column indices (0-based) in the Systems sheet
SYS_COL_SYSTEM_ID       = 14  # O
SYS_COL_SYSTEM_NAME     = 15  # P
SYS_COL_PRODUCT_LINE    = 16  # Q
SYS_COL_PRODUCT_VERSION = 17  # R
SYS_COL_EOMM            = 18  # S
SYS_COL_BTT             = 19  # T
SYS_COL_USERS           = 20  # U
SYS_COL_DB_SIZE         = 21  # V
SYS_COL_LAST_EWA        = 22  # W
SYS_COL_DATABASE        = 23  # X
SYS_COL_MOVE_STATUS     = 1   # B - Move Status Merged
SYS_COL_PE_NAME         = 34  # AI - Planning Entity Name
SYS_COL_PE_CRM_ZEROS    = 38  # AM - Planning Entity CRM ID with Zeros

# ── Pre-loaded data (loaded once at startup) ──────────────────────────
_ALL_ROWS    = None   # raw customer rows
_ALL_RECORDS = None   # cleaned customer records
_SYSTEMS_IDX = None   # crm_id -> [system records]

def normalise_crm_id(v):
    if v is None:
        return ''
    return str(v).strip().zfill(10)

def load_data():
    """Read both worksheets once at startup and keep everything in memory."""
    global _ALL_ROWS, _ALL_RECORDS, _SYSTEMS_IDX
    filepath = DEFAULT_FILE
    if not filepath or not os.path.exists(filepath):
        print('WARNING: data file not found, dashboard will be empty.')
        _ALL_ROWS    = []
        _ALL_RECORDS = []
        _SYSTEMS_IDX = {}
        return
    print(f'Loading data from: {os.path.basename(filepath)} ...', flush=True)
    _ALL_ROWS    = read_xlsb_customers(filepath)
    _ALL_RECORDS = rows_to_records(filter_rows(_ALL_ROWS))
    _SYSTEMS_IDX = read_xlsb_systems(filepath)
    print(f'Loaded {len(_ALL_RECORDS)} customer records and '
          f'{sum(len(v) for v in _SYSTEMS_IDX.values())} system records.', flush=True)

def read_xlsb_systems(filepath):
    index = {}  # crm_id (10-char zero-padded) -> [records]
    with open_workbook(filepath) as wb:
        with wb.get_sheet('Systems') as sheet:
            for i, row in enumerate(sheet.rows()):
                if i == 0:
                    continue
                vals = [cell.v for cell in row]
                while len(vals) <= SYS_COL_PE_CRM_ZEROS:
                    vals.append(None)
                crm_id = normalise_crm_id(vals[SYS_COL_PE_CRM_ZEROS])
                if not crm_id:
                    continue
                record = {
                    'system_id':       safe_val(vals[SYS_COL_SYSTEM_ID]),
                    'system_name':     safe_val(vals[SYS_COL_SYSTEM_NAME]),
                    'product_line':    safe_val(vals[SYS_COL_PRODUCT_LINE]),
                    'product_version': safe_val(vals[SYS_COL_PRODUCT_VERSION]),
                    'eomm':            safe_val(vals[SYS_COL_EOMM]),
                    'users':           safe_val(vals[SYS_COL_USERS]),
                    'db_size_gb':      safe_val(vals[SYS_COL_DB_SIZE]),
                    'last_ewa':        safe_val(vals[SYS_COL_LAST_EWA]),
                    'database':        safe_val(vals[SYS_COL_DATABASE]),
                    'move_status':     safe_val(vals[SYS_COL_MOVE_STATUS]),
                    'pe_name':         safe_val(vals[SYS_COL_PE_NAME]),
                }
                index.setdefault(crm_id, []).append(record)
    return index

def get_filtered_records(filters=None):
    """Apply filters to the pre-loaded records and return matching rows."""
    return rows_to_records(filter_rows(_ALL_ROWS, filters))

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/detail')
def detail():
    return send_from_directory('static', 'detail.html')

@app.route('/api/systems/<crm_id>', methods=['GET'])
def get_system_detail(crm_id):
    if _ALL_ROWS is None:
        return jsonify({'error': 'No data loaded'}), 503
    normalised = normalise_crm_id(crm_id)
    customer = None
    for vals in _ALL_ROWS:
        cid = normalise_crm_id(vals[COL_PLANNING_ENTITY_CRM])
        if cid == normalised:
            customer = {
                'planning_entity_name': safe_val(vals[COL_PLANNING_ENTITY_NAME]),
                'planning_entity_crm':  normalised,
                'country':              safe_val(vals[COL_COUNTRY]),
                'market_unit':          safe_val(vals[COL_MARKET_UNIT]),
                'region':               safe_val(vals[COL_REGION]),
                'int_sales_seg':        safe_val(vals[COL_INT_SALES_SEG]),
                'account_owner':        safe_val(vals[COL_ACCOUNT_OWNER]),
            }
            break
    systems = _SYSTEMS_IDX.get(normalised, [])
    return jsonify({
        'crm_id':   normalised,
        'customer': customer,
        'systems':  systems,
    })


@app.route('/api/init', methods=['GET'])
def init():
    if not _ALL_RECORDS:
        return jsonify({'error': 'Data not loaded'}), 503
    records = _ALL_RECORDS
    return jsonify({
        'total_records':  len(records),
        'filter_options': build_filter_options(records),
        'country_counts': build_country_counts(records),
        'kpis':           build_kpis(records),
        'region_tree':    build_region_tree(records),
        'country_list':   build_country_list(records),
        'gap_map':        build_gap_map(records),
        'country_records': records,
        'source':         'default',
        'filename':       os.path.basename(DEFAULT_FILE) if DEFAULT_FILE else '',
    })

@app.route('/api/data', methods=['POST'])
def get_data():
    if _ALL_ROWS is None:
        return jsonify({'error': 'Data not loaded'}), 503
    body = request.get_json() or {}
    filters = body.get('filters', {})
    country = body.get('country', None)

    records = get_filtered_records(filters)
    country_records = [r for r in records if r['country'] == country] if country else records

    return jsonify({
        'total_records':   len(records),
        'country_counts':  build_country_counts(records),
        'filter_options':  build_filter_options(records),
        'kpis':            build_kpis(records),
        'region_tree':     build_region_tree(records),
        'country_list':    build_country_list(records),
        'gap_map':         build_gap_map(records),
        'country_records': country_records,
    })

@app.route('/api/search', methods=['GET'])
def search():
    q = (request.args.get('q') or '').strip().lower()
    if len(q) < 2:
        return jsonify({'results': []}), 200
    results = []
    seen = set()
    for vals in _ALL_ROWS:
        name = str(safe_val(vals[COL_PLANNING_ENTITY_NAME])).strip()
        crm  = str(safe_val(vals[COL_PLANNING_ENTITY_CRM])).strip()
        if name.lower().find(q) >= 0 or crm.find(q) >= 0:
            key = normalise_crm_id(crm)
            if key not in seen:
                seen.add(key)
                results.append({
                    'name':    name,
                    'crm_id':  normalise_crm_id(crm),
                    'country': str(safe_val(vals[COL_COUNTRY])).strip(),
                    'mu':      str(safe_val(vals[COL_MARKET_UNIT])).strip(),
                })
        if len(results) >= 20:
            break
    return jsonify({'results': results})

@app.route('/api/export', methods=['POST'])
def export():
    if _ALL_ROWS is None:
        return Response('No data', status=503)
    body = request.get_json() or {}
    filters = body.get('filters', {})
    country = body.get('country', None)

    records = get_filtered_records(filters)
    if country:
        records = [r for r in records if r['country'] == country]

    csv_data = records_to_csv(records)
    filename = f"CRM_export_{country or 'all'}.csv".replace(' ', '_')
    return Response(
        csv_data,
        mimetype='text/csv',
        headers={'Content-Disposition': f'attachment; filename="{filename}"'}
    )


def build_country_counts(records):
    counts = {}
    for r in records:
        c = r['country']
        if c:
            counts[c] = counts.get(c, 0) + 1
    return counts

def build_filter_options(records):
    opts = {k: set() for k in ['col_i', 'col_k', 'col_l', 'col_m', 'col_s', 'col_ao', 'col_ap']}
    field_map = {
        'col_i':  'int_sales_seg',
        'col_k':  'account_owner',
        'col_l':  'sse_specialist',
        'col_m':  'mtc_band',
        'col_s':  'hdb',
        'col_ao': 'rise_opportunity',
        'col_ap': 's4_pto_opportunity',
    }
    for r in records:
        for col_key, field in field_map.items():
            v = str(r[field]) if r[field] != '' else None
            if v:
                opts[col_key].add(v)
    return {k: sorted(list(v)) for k, v in opts.items()}

def build_kpis(records):
    market_units = set()
    rise_opps = 0
    erp_pvt_opps = 0
    for r in records:
        if r['market_unit']:
            market_units.add(r['market_unit'])
        if str(r['rise_opportunity']).strip() == 'Yes':
            rise_opps += 1
        if str(r['erp_private_opp']).strip() == 'Yes':
            erp_pvt_opps += 1
    return {
        'total_opps':      len(records),
        'countries':       len(set(r['country'] for r in records if r['country'])),
        'market_units':    len(market_units),
        'rise_opps':       rise_opps,
        'erp_pvt_opps':    erp_pvt_opps,
    }

def build_region_tree(records):
    """Returns {region: [market_units]}"""
    tree = {}
    for r in records:
        reg = r['region']
        mu  = r['market_unit']
        if not reg:
            continue
        tree.setdefault(reg, set())
        if mu:
            tree[reg].add(mu)
    return {k: sorted(list(v)) for k, v in sorted(tree.items())}

def build_country_list(records):
    """Returns sorted list of countries present in current filtered records."""
    return sorted(set(r['country'] for r in records if r['country']))

def build_gap_map(records):
    """Per country: has_rise, has_erp, total — for opportunity gap colouring."""
    data = {}
    for r in records:
        c = r['country']
        if not c:
            continue
        if c not in data:
            data[c] = {'total': 0, 'has_rise': 0, 'has_erp': 0}
        data[c]['total'] += 1
        if str(r['rise_opportunity']).strip() == 'Yes':
            data[c]['has_rise'] += 1
        if str(r['erp_private_opp']).strip() == 'Yes':
            data[c]['has_erp'] += 1
    return data

def records_to_csv(records):
    """Serialise filtered records to CSV string."""
    if not records:
        return ''
    fields = [
        ('Planning Entity', 'planning_entity_name'),
        ('CRM No', 'planning_entity_crm'),
        ('Region', 'region'),
        ('Market Unit', 'market_unit'),
        ('Country', 'country'),
        ('Int. Sales Seg.', 'int_sales_seg'),
        ('Account Owner', 'account_owner'),
        ('SSE Specialist', 'sse_specialist'),
        ('Maintenance Band', 'mtc_band'),
        ('CRM OP', 'crm_op'),
        ('HDB', 'hdb'),
        ('ASE', 'ase'),
        ('Max DB', 'max_db'),
        ('Oracle', 'oracle'),
        ('MS SQL', 'ms_sql'),
        ('IBM/DB2', 'ibm_db2'),
        ('Others', 'others'),
        ('ERP Priv. License', 'erp_private_license'),
        ('ERP Priv. Opp', 'erp_private_opp'),
        ('ERP PTO Opp', 'erp_pto_opp'),
        ('RISE License', 'rise_license'),
        ('RISE Opportunity', 'rise_opportunity'),
        ('S/4 PTO Opportunity', 's4_pto_opportunity'),
    ]
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=[f[0] for f in fields], extrasaction='ignore')
    writer.writeheader()
    for r in records:
        writer.writerow({label: r.get(key, '') for label, key in fields})
    return output.getvalue()


if __name__ == '__main__':
    print('\n' + '='*50)
    print('  CX Demand Generation Dashboard')
    print('  Open: http://localhost:3000')
    print('='*50 + '\n')
    load_data()
    app.run(host='0.0.0.0', port=3000, debug=False)
